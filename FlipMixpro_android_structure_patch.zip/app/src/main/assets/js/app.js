document.querySelectorAll("[data-deck]").forEach((button) => {
  button.addEventListener("click", () => {
    const deck = button.dataset.deck.toUpperCase();
    const playing = button.dataset.playing !== "true";
    button.dataset.playing = String(playing);
    button.textContent = playing ? "PAUSE " + deck : "PLAY " + deck;
    const message = document.getElementById("message");
    if (message) message.textContent = "Deck " + deck + (playing ? " je spuštěný." : " je pozastavený.");
  });
});
