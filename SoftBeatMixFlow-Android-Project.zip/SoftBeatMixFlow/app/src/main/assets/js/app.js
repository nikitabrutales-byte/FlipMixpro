(() => {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  let ctx = null;
  let masterGain = null;
  const decks = {};
  const $ = id => document.getElementById(id);
  const fmt = n => { if(!Number.isFinite(n)) return "00:00"; const m=Math.floor(n/60),s=Math.floor(n%60); return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`; };
  function audio(){ if(!ctx) ctx = new AudioCtx(); if(ctx.state==="suspended") ctx.resume(); return ctx; }
  function makeDeck(id){
    const c=audio(), el=new Audio(); el.preload="metadata";
    if(!masterGain){masterGain=c.createGain();masterGain.gain.value=+$("master").value;masterGain.connect(c.destination);}
    const source=c.createMediaElementSource(el), low=c.createBiquadFilter(), mid=c.createBiquadFilter(), high=c.createBiquadFilter(), gain=c.createGain(), mixGain=c.createGain(), pan=c.createStereoPanner();
    low.type="lowshelf";low.frequency.value=180;mid.type="peaking";mid.frequency.value=1000;mid.Q.value=.8;high.type="highshelf";high.frequency.value=5000;
    source.connect(low).connect(mid).connect(high).connect(gain).connect(mixGain).connect(pan).connect(masterGain);
    const d={el,low,mid,high,gain,mixGain,pan,userGain:1,objectUrl:null}; decks[id]=d;
    el.addEventListener("loadedmetadata",()=>{$(`duration-${id}`).textContent=fmt(el.duration);$(`state-${id}`).textContent="LOADED";drawWave(id);});
    el.addEventListener("timeupdate",()=>{$(`time-${id}`).textContent=fmt(el.currentTime);$(`seek-${id}`).value=el.duration?el.currentTime/el.duration*1000:0;});
    el.addEventListener("ended",()=>{$(`state-${id}`).textContent="ENDED";$(`play-${id}`)?.classList.remove("active");});
    return d;
  }
  makeDeck("a");makeDeck("b");
  ["a","b"].forEach(id=>{
    $(`file-${id}`).addEventListener("change",e=>{
      const file=e.target.files?.[0];if(!file)return;const d=decks[id];
      if(d.objectUrl)URL.revokeObjectURL(d.objectUrl);d.objectUrl=URL.createObjectURL(file);d.el.src=d.objectUrl;d.el.load();
      $(`name-${id}`).textContent=file.name;$(`state-${id}`).textContent="LOADING";
    });
    $(`seek-${id}`).addEventListener("input",e=>{const d=decks[id];if(d.el.duration)d.el.currentTime=(+e.target.value/1000)*d.el.duration;});
    ["gain","low","mid","high"].forEach(k=>$(`${k}-${id}`).addEventListener("input",e=>{
      const d=decks[id],v=+e.target.value;if(k==="gain"){d.userGain=v;d.gain.gain.value=v;}else d[k].gain.value=v;
    }));
  });
  document.querySelectorAll("[data-action]").forEach(btn=>btn.addEventListener("click",async()=>{
    const id=btn.dataset.deck,d=decks[id];audio();
    if(btn.dataset.action==="play"){if(d.el.paused){try{await d.el.play();$(`state-${id}`).textContent="PLAYING";btn.textContent="Ⅱ";}catch(e){$(`state-${id}`).textContent="LOAD TRACK";}}else{d.el.pause();$(`state-${id}`).textContent="PAUSED";btn.textContent="▶";}}
    if(btn.dataset.action==="stop"){d.el.pause();d.el.currentTime=0;btn.textContent="▶";$(`state-${id}`).textContent="STOPPED";}
    if(btn.dataset.action==="cue"){d.el.pause();d.el.currentTime=0;btn.textContent="▶";$(`state-${id}`).textContent="CUE";}
  }));
  function updateCrossfader(){const x=+$("crossfader").value;decks.a.mixGain.gain.value=1-x;decks.b.mixGain.gain.value=x;}
  $("crossfader").addEventListener("input",updateCrossfader);updateCrossfader();
  $("master").addEventListener("input",e=>{if(masterGain)masterGain.gain.value=+e.target.value;});
  let bpm=128;function showBpm(){$("bpm-value").textContent=bpm.toFixed(1)}$("bpm-down").onclick=()=>{bpm=Math.max(60,bpm-.1);showBpm()};$("bpm-up").onclick=()=>{bpm=Math.min(200,bpm+.1);showBpm()};
  function drawWave(id){const canvas=$(`wave-${id}`),g=canvas.getContext("2d"),w=canvas.width=canvas.clientWidth*devicePixelRatio,h=canvas.height=100*devicePixelRatio;g.clearRect(0,0,w,h);g.strokeStyle="#b7d9c9";g.globalAlpha=.8;g.lineWidth=1*devicePixelRatio;const seed=id==="a"?17:29;for(let x=0;x<w;x+=3*devicePixelRatio){const v=Math.abs(Math.sin(x*.035+seed)*Math.cos(x*.011+seed*.4));const a=(5+v*34)*devicePixelRatio;g.beginPath();g.moveTo(x,h/2-a);g.lineTo(x,h/2+a);g.stroke();}}
  window.addEventListener("resize",()=>["a","b"].forEach(drawWave));
  ["a","b"].forEach(drawWave);
})();
